# Image-Generative-Prompt-Classification
Melakukan klasifikasi prompt dari website AI Image Generative menjadi beberapa kelompok.
